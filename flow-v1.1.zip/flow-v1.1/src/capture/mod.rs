use anyhow::{Result, anyhow};
use tokio::net::{TcpListener, TcpStream};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tracing::{info, warn, error};
use std::path::Path;
use std::fs;
use chrono::Utc;

pub async fn run_proxy_capture(out: &str, proxy: &str, include: &[String], exclude: &[String], _max_size: u64, intercept: bool) -> Result<()> {
    if intercept {
        warn!("TLS intercept is disabled in v1.1; proceeding without MITM.");
    }
    prepare_shot_dirs(out)?;
    let addr = if proxy.starts_with(':') { format!("127.0.0.1{}", proxy) } else { proxy.to_string() };
    let listener = TcpListener::bind(&addr).await?;
    info!("Flow proxy listening on {}", &addr);
    loop {
        let (mut client, _) = listener.accept().await?;
        let out = out.to_string();
        let include = include.to_vec();
        let exclude = exclude.to_vec();
        tokio::spawn(async move {
            if let Err(e) = handle_client(&mut client, &out, &include, &exclude).await {
                error!("proxy error: {e:?}");
            }
        });
    }
}

fn prepare_shot_dirs(out: &str) -> Result<()> {
    let base = Path::new(out);
    for p in ["requests","responses","canonical","proofs","sig"] {
        fs::create_dir_all(base.join(p))?;
    }
    Ok(())
}

async fn handle_client(client: &mut TcpStream, out: &str, include: &[String], exclude: &[String]) -> Result<()> {
    let mut peek = [0u8; 4096];
    let n = client.peek(&mut peek).await?;
    if n == 0 { return Ok(()); }
    let text = String::from_utf8_lossy(&peek[..n]);
    if text.starts_with("CONNECT ") {
        let host = text.split_whitespace().nth(1).unwrap_or("unknown");
        if !is_allowed(host, include, exclude) { let _ = client.read(&mut peek).await?; return Ok(()); }
        let _ = client.read(&mut peek).await?; // consume
        let mut server = TcpStream::connect(host).await?;
        client.write_all(b"HTTP/1.1 200 Connection Established\r\n\r\n").await?;
        write_entry(out, "CONNECT", host, "/", 200, b"", b"").await?;
        let (mut cr, mut cw) = client.split();
        let (mut sr, mut sw) = server.split();
        let c2s = tokio::io::copy(&mut cr, &mut sw);
        let s2c = tokio::io::copy(&mut sr, &mut cw);
        let _ = tokio::try_join!(c2s, s2c);
        return Ok(());
    } else {
        // plaintext HTTP
        let _ = client.read(&mut peek).await?; // consume
        let first = text.lines().next().unwrap_or("GET / HTTP/1.1").to_string();
        let mut parts = first.split_whitespace();
        let method = parts.next().unwrap_or("GET").to_string();
        let path = parts.nth(1).unwrap_or("/").to_string();
        let host = text.lines().find(|l| l.to_lowercase().starts_with("host:"))
            .and_then(|l| l.split(':').nth(1)).map(|s| s.trim().to_string()).unwrap_or("localhost:80".to_string());
        if !is_allowed(&host, include, exclude) { return Ok(()); }
        let target = if host.contains(':') { host.clone() } else { format!("{host}:80") };
        let mut server = TcpStream::connect(target).await?;
        server.write_all(&peek[..n]).await?;
        let mut resp = Vec::new();
        let mut tmp = [0u8; 65536];
        let n2 = server.read(&mut tmp).await?;
        resp.extend_from_slice(&tmp[..n2]);
        client.write_all(&resp).await?;
        write_entry(out, &method, &host, &path, 200, &peek[..n], &resp).await?;
        return Ok(());
    }
}

fn is_allowed(host: &str, include: &[String], exclude: &[String]) -> bool {
    let pass_inc = if include.is_empty() { true } else { include.iter().any(|h| host.contains(h)) };
    let pass_exc = !exclude.iter().any(|h| host.contains(h));
    pass_inc && pass_exc
}

async fn write_entry(out: &str, method: &str, host: &str, path: &str, status: i32, req_bytes: &[u8], res_bytes: &[u8]) -> Result<()> {
    use std::fs;
    use std::io::Write;
    use std::path::Path;
    let ts = Utc::now().to_rfc3339();
    let id = Utc::now().timestamp_nanos_opt().unwrap_or(0).to_string();
    let id_short = &id[id.len().saturating_sub(6)..];
    let base = Path::new(out);
    fs::write(base.join(format!("requests/{}.req", id_short)), req_bytes)?;
    fs::write(base.join(format!("responses/{}.res", id_short)), res_bytes)?;
    let canon = format!("{{\"id\":\"{}\",\"req\":{{\"method\":\"{}\",\"host\":\"{}\",\"path\":\"{}\"}},\"res\":{{\"status\":{}}}}}\n", id_short, method, host, path, status);
    fs::write(base.join(format!("canonical/{}.jsonl", id_short)), canon.as_bytes())?;
    fs::OpenOptions::new().create(true).append(true).open(base.join("proofs/chain.ndjson"))?.write_all(format!("{{\"id\":\"{}\",\"req_b3\":\"TODO\",\"res_b3\":\"TODO\",\"prev_b3\":null}}\n", id_short).as_bytes())?;
    let manifest_path = base.join("manifest.json");
    let entry = format!(r#"{{ \"id\": \"{id}\", \"ts\": \"{ts}\", \"request_ref\": \"requests/{id_short}.req\", \"response_ref\": \"responses/{id_short}.res\", \"canonical_ref\": \"canonical/{id_short}.jsonl\", \"req_b3\": \"TODO\", \"res_b3\": \"TODO\", \"meta\": {{ \"method\": \"{method}\", \"host\": \"{host}\", \"path\": \"{path}\", \"status\": {status}, \"latency_ms\": 0, \"tags\": [\"capture\"] }} }}"#);
    if !manifest_path.exists() {
        let content = format!(r#"{{ \"version\": \"1.0\", \"created_at\": \"{ts}\", \"tool\": {{ \"name\": \"flow\", \"version\": \"1.1.0\", \"binary_b3\": \"TODO\" }}, \"capture\": {{ \"mode\": \"proxy\", \"listener\": \"unknown\", \"filters\": {{ \"include\": [], \"exclude\": [] }} }}, \"entries\": [ {entry} ], \"integrity\": {{ \"chain_b3\": \"proofs/chain.ndjson\", \"policy_b3\": null, \"prev_bundle_b3\": null }}, \"signature\": {{ \"ed25519_pub\": null, \"sig_ref\": null }} }}"#);
        fs::write(&manifest_path, content.as_bytes())?;
    } else {
        let mut content = fs::read_to_string(&manifest_path)?;
        if let Some(pos) = content.rfind(']') {
            content.insert_str(pos, &format!(",\n{entry}\n"));
            fs::write(&manifest_path, content.as_bytes())?;
        }
    }
    Ok(())
}
