use anyhow::Result;

pub async fn cmd_record(out: String, proxy: String, include: Vec<String>, exclude: Vec<String>, max_size: u64, intercept: bool) -> Result<()> {
    crate::capture::run_proxy_capture(&out, &proxy, &include, &exclude, max_size, intercept).await
}
pub async fn cmd_pack(input: String, output: String, sign: Option<String>, deterministic: bool) -> Result<()> {
    crate::pack::pack_shot(&input, &output, sign.as_deref(), deterministic).await
}
pub async fn cmd_replay(bundle: String, map: Vec<String>, concurrency: usize) -> Result<()> {
    crate::replay::replay_bundle(&bundle, &map, concurrency).await
}
pub async fn cmd_verify(bundle: String, policy: Option<String>, require_signature: bool) -> Result<()> {
    crate::verify::verify_bundle(&bundle, policy.as_deref(), require_signature).await
}
pub async fn cmd_diff(a: String, b: String) -> Result<()> { crate::util::diff_bundles(&a, &b).await }
pub async fn cmd_gen_cert(cn: String) -> Result<()> { crate::crypto::gen_local_ca(&cn).await }
pub async fn cmd_redact(policy: String, input: String) -> Result<()> { crate::util::apply_redaction(&policy, &input).await }
