use anyhow::Result;
use clap::{Parser, Subcommand};

mod cli;
mod capture;
mod normalize;
mod pack;
mod replay;
mod verify;
mod crypto;
mod util;

#[derive(Parser, Debug)]
#[command(name = "flow", version, about = "Deterministic HTTP record→replay→verify")]
struct Args {
    #[command(subcommand)]
    cmd: Command
}

#[derive(Subcommand, Debug)]
enum Command {
    Record { #[arg(long)] out: String, #[arg(long, default_value=":8080")] proxy: String, #[arg(long)] include: Vec<String>, #[arg(long)] exclude: Vec<String>, #[arg(long, default_value="52428800")] max_size: u64, #[arg(long, default_value_t=false)] intercept: bool },
    Pack { #[arg(long)] r#in: String, #[arg(long)] out: String, #[arg(long)] sign: Option<String>, #[arg(long, default_value_t=false)] deterministic: bool },
    Replay { bundle: String, #[arg(long)] map: Vec<String>, #[arg(long, default_value_t=1)] concurrency: usize },
    Verify { bundle: String, #[arg(long)] policy: Option<String>, #[arg(long, default_value_t=false)] require_signature: bool },
    Diff { a: String, b: String },
    GenCert { #[arg(long, default_value="flow-local")] cn: String },
    Redact { #[arg(long)] policy: String, #[arg(long)] r#in: String }
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
      .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
      .init();
    let args = Args::parse();
    match args.cmd {
        Command::Record { out, proxy, include, exclude, max_size, intercept } => cli::cmd_record(out, proxy, include, exclude, max_size, intercept).await,
        Command::Pack { r#in, out, sign, deterministic } => cli::cmd_pack(r#in, out, sign, deterministic).await,
        Command::Replay { bundle, map, concurrency } => cli::cmd_replay(bundle, map, concurrency).await,
        Command::Verify { bundle, policy, require_signature } => cli::cmd_verify(bundle, policy, require_signature).await,
        Command::Diff { a, b } => cli::cmd_diff(a, b).await,
        Command::GenCert { cn } => cli::cmd_gen_cert(cn).await,
        Command::Redact { policy, r#in } => cli::cmd_redact(policy, r#in).await,
    }
}
