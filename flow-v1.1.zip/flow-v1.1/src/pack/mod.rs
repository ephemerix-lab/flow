use anyhow::Result;
use std::path::Path;
use std::fs::{self, File};
use std::io::Write;
use zip::write::FileOptions;

pub async fn pack_shot(input: &str, output: &str, _sign_pem: Option<&str>, deterministic: bool) -> Result<()> {
    let file = File::create(output)?;
    let mut zip = zip::ZipWriter::new(file);
    let opts = if deterministic {
        FileOptions::default().last_modified_time(zip::DateTime::from_date_and_time(1980,1,1,0,0,0).unwrap())
    } else { FileOptions::default() };

    let top = ["manifest.json","proofs/chain.ndjson"];
    for t in top {
        let p = Path::new(input).join(t);
        if p.exists() { zip.start_file(t, opts)?; zip.write_all(&fs::read(p)?)?; }
    }
    for dir in ["requests","responses","canonical"] {
        let mut entries: Vec<_> = fs::read_dir(Path::new(input).join(dir))?.filter_map(|e| e.ok()).map(|e| e.path()).collect();
        entries.sort();
        for p in entries {
            let rel = p.strip_prefix(input).unwrap().to_string_lossy().replace("\\","/");
            zip.start_file(rel, opts)?; zip.write_all(&fs::read(p)?)?;
        }
    }
    zip.finish()?; Ok(())
}
