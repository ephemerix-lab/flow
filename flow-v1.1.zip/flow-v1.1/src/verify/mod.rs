use anyhow::{Result, anyhow};
use std::fs;
pub async fn verify_bundle(bundle: &str, _policy: Option<&str>, require_signature: bool) -> Result<()> {
    let bytes = fs::read(bundle)?;
    let has_sig = bytes.windows(12).any(|w| w == b"manifest.sig");
    if require_signature && !has_sig { return Err(anyhow!("signature required but missing")); }
    Ok(())
}
