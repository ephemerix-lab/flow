# Flow v1.1

Deterministic HTTP **record → pack → verify** with cryptographic proof trails.
- Live **HTTP/1.1 proxy capture** (no TLS intercept). CONNECT is tunneled; HTTPS contents are not captured (only metadata). 
- Deterministic pack (`--deterministic`) and basic verify implemented.
- TLS intercept remains **OFF by default** for safety.

## Quick demo (HTTP)
In one shell run a simple server (python):
```bash
python3 -m http.server 9000
```
In another shell, run Flow and route `curl` through it:
```bash
RUST_LOG=info cargo run -- record --out shot1 --proxy :8080 --include localhost:9000
curl -x http://127.0.0.1:8080 http://localhost:9000/
cargo run -- pack --in shot1 --out flow.bundle.zip --deterministic
cargo run -- verify flow.bundle.zip --policy examples/verify.yaml
```

For HTTPS, use CONNECT tunneling:
```bash
curl -x http://127.0.0.1:8080 https://example.com/ -k
# Flow v1.1 records CONNECT metadata only, not encrypted payloads.
```

## Layout
```
src/{cli,capture,normalize,pack,replay,verify,crypto,util}/*.rs
schemas/{manifest_v1.json,verify_v1.json}
examples/{verify.yaml,redact.yaml}
tests/{e2e.rs,determinism.rs}
.github/workflows/ci.yml
```
